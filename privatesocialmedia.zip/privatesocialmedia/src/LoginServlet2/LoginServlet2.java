package LoginServlet2;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ResetPasswordServlet.EmailUtility;


@WebServlet("/LoginServlet2")
public class LoginServlet2 extends HttpServlet {
    private static final Random RANDOM = new SecureRandom();
    private static final String NUMBER = "0123456789";
    private static final long serialVersionUID = 1L;
 
    private String host;
    private String port;
    private String email;
    private String name;
    private String pass;
 
    public void init() {
        // reads SMTP server setting from web.xml file
        ServletContext context = getServletContext();
        host = context.getInitParameter("host");
        port = context.getInitParameter("port");
        email = context.getInitParameter("email");
        name = context.getInitParameter("name");
        pass = context.getInitParameter("pass");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();


try {
	String email1 = request.getParameter("username");
	String pass1 = request.getParameter("userpass");
	String algorithm = "SHA-256";
	String hash = generateHash(pass1,algorithm);
	Class.forName("com.mysql.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("select * from register where email='"+email1+"' and hash='"+hash+"'");
    
    if(rs.next())
    {
    	String name = rs.getString(2);

        String subject = "Two Step Verification";
        // Define desired password length
        int OtpLength = 4;
        
        // Generate Secure Password
        String otp = generateOtp(OtpLength);
        
        st.executeUpdate("insert into newotp values('"+name+"','"+otp+"');");
     
        String content ="OTP : "+otp;
        EmailUtility.sendEmail(host, port, email, name, pass,
                email1, subject, content);
        
	    request.setAttribute("myname",name);
	    request.getRequestDispatcher("verify.jsp").forward(request, response);
    	
    
    }
                else
        {
            out.println("<!DOCTYPE html>"); 
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Serv12</title>"); 
        	out.print("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">\n" + 
        			"");
            out.println("</head>");
            out.println("<body>");
            out.println("<center><h1>Invalid user</h1></center>"); 
            out.println("<center><button  class=\"btn btn-danger\"><a href=\"login.html\" style=\"color:white;\">Login</a></button></center>");
            out.println("</body>");
            out.println("</html>"); 
        }
    
    
    
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (NoSuchAlgorithmException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (AddressException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (MessagingException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

    }
    
    public static String generateOtp(int length) {
        StringBuilder returnValue = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            returnValue.append(NUMBER.charAt(RANDOM.nextInt(NUMBER.length())));
        }
        return new String(returnValue);
    }
    
	private static String generateHash(String data, String algorithm) throws NoSuchAlgorithmException {
	     MessageDigest digest = MessageDigest.getInstance(algorithm);
	     digest.reset();
	     byte[] hash = digest.digest(data.getBytes());
	     return bytesToStringHex(hash);
	     
			
		}
	
	private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
	private static String bytesToStringHex(byte[] bytes) {
char[] hexChars = new char[bytes.length * 2];
for(int j=0;j<bytes.length;j++)
{
	int v = bytes[j] & 0xFF;
	hexChars[j*2] = hexArray[v >>> 4];
	hexChars[j*2+1]=hexArray[v & 0x0F];
}
return new String(hexChars);
	}
}
