package AcceptServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AcceptServlet")
public class AcceptServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();

try {
	String sender = request.getParameter("sender");
	String receiver = request.getParameter("receiver");
	Class.forName("com.mysql.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
	Statement st = con.createStatement();
	ResultSet rs = st.executeQuery("select * from friends1 where sender='"+sender+"' and receiver='"+receiver+"';");
	
	if(!rs.next())
	{
	PreparedStatement ps = con.prepareStatement("insert into friends1(sender,receiver) values(?,?);");
	ps.setString(1, sender);
	ps.setString(2, receiver);
	ps.execute();
	}

	st.executeUpdate("delete from newfriend where sender='"+sender+"' and receiver='"+receiver+"';");
	
	response.sendRedirect("notification.jsp");
	
	
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

    }
}
