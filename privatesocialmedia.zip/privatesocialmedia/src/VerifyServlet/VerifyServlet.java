package VerifyServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/VerifyServlet")
public class VerifyServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();


String otp = request.getParameter("otp");
try {
	Class.forName("com.mysql.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
    Statement st = con.createStatement();
    String name = request.getParameter("name");
    ResultSet rs = st.executeQuery("select * from newotp where name1='"+name+"' and otp='"+otp+"'");
    if(rs.next())
    {
    	       	st.executeUpdate("delete from newotp;");
    	        Cookie ck1=new Cookie("name",name);  
    	        response.addCookie(ck1); 
    	        out.println("<!DOCTYPE html>"); 
    	        out.println("<html>");
    	       out.println("<head>");
    	       out.println("<title>Servlet Serv12</title>");
    	   	out.print("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">\n" + 
    	   			"");
    	       out.println("</head>");
    	       out.println("<body>");
    	       out.println("<center><h1> Welcome " + name +"</h1></center>"); 
    	       out.println("<form action=\"ProfileServlet1\" method=\"post\">\n" + 
    	       		"<center><input type=\"submit\" value=\"Profile\" class=\"btn btn-primary\"/></center>\n" + 
    	       		"</form><br>");
    	       out.println("<form action=\"LogoutServlet1\" method=\"post\">\n"
    	       		+ "<center><input type=\"submit\" value=\"Logout\" class=\"btn btn-danger\"/></center>\n" +
    	       				"    </form>");
    	       out.println("</body>");
    	       out.println("</html>");
    }
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

    }
}
