package FollowerServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/FollowerServlet")
public class FollowerServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();

try {
	String name1 = request.getParameter("name");
	Class.forName("com.mysql.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
    Statement st = con.createStatement();
	Cookie ck[]=request.getCookies();  
	if(ck!=null){
	for(int i=0;i<ck.length;i++)
	{
	String name=ck[i].getValue(); 
	ResultSet rs = st.executeQuery("select * from register where name1='"+name+"'");

	if(rs.next())
	{

	if(!name.equals("")||name!=null)
	{
		ResultSet rs1 = st.executeQuery("select * from friends1 where sender='"+name+"' and receiver='"+name1+"';");
		if(!rs1.next())
		{
		PreparedStatement ps = con.prepareStatement("insert into friends1(sender,receiver) values(?,?);");
		ps.setString(1, name);
		ps.setString(2, name1);
		ps.execute();
		}
		response.sendRedirect("follower.jsp");
	}
	}
	}
	}
	
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

    }
}
