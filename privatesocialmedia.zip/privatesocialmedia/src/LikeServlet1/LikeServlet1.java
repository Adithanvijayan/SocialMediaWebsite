package LikeServlet1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LikeServlet1")
public class LikeServlet1 extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();
try {
	String value = request.getParameter("id");
	String value1 = request.getParameter("like");
	String name1 = request.getParameter("name");
	String name = request.getParameter("name1");
	int id = Integer.parseInt(value);
	int like = Integer.parseInt(value1);
	Class.forName("com.mysql.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("select * from like1 where post_id='"+id+"' and name1='"+name+"';");
    if(!rs.next())
    {
    	st.executeUpdate("insert into like1 values('"+id+"','"+name+"');");
    like=like+1;
    st.executeUpdate("update post2 set like1='"+like+"' where post_id='"+id+"';");
    }
    request.setAttribute("myname",name1);
    request.getRequestDispatcher("profile2.jsp").forward(request, response);
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}

}
