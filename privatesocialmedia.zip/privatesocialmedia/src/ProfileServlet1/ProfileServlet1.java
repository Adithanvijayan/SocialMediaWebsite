package ProfileServlet1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProfileServlet1")
public class ProfileServlet1 extends HttpServlet {


    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
               throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();
 
try {
	Class.forName("com.mysql.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
    Statement st = con.createStatement();
    Cookie ck[]=request.getCookies();  
if(ck!=null){
	for(int i=0;i<ck.length;i++)
	{
String name=ck[i].getValue(); 
    ResultSet rs = st.executeQuery("select * from register where name1='"+name+"'");

if(rs.next())
{

if(!name.equals("")||name!=null){  
    request.setAttribute("name", name);
    request.getRequestDispatcher("index.jsp").forward(request, response);
break;
} 
}
    }
}
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
    }
}
