package RegisterServlet1;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet1")
public class RegisterServlet1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {  
response.setContentType("text/html");  
PrintWriter out=response.getWriter();


try {
	String name = request.getParameter("name");
	String phone = request.getParameter("phone");
	String email = request.getParameter("email");
	String pass = request.getParameter("userpass");
	String algorithm = "SHA-256";
	String hash = generateHash(pass,algorithm);
	if(name.equals("") || phone.length()<10 || hash.equals("E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855"))
	{
		response.sendRedirect("failure.html");
		return ;
	}
	Class.forName("com.mysql.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
	Statement st = con.createStatement();
	ResultSet rs = st.executeQuery("select * from register where email='"+email+"' or name1='"+name+"'");
	if(rs.next())
	{
        out.println("<!DOCTYPE html>"); 
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Servlet Serv12</title>"); 
    	out.print("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">\n" + 
    			"");
        out.println("</head>");
        out.println("<body>");
        out.println("<center><h1>username already registered</h1></center>"); 
        out.println("<center><button  class=\"btn btn-danger\"><a href=\"register.html\" style=\"color:white;\">Register</a></button></center>");
        out.println("</body>");
        out.println("</html>"); 
	}
	else
	{
		PreparedStatement ps = con.prepareStatement("insert into register(name1,phone,email,hash) values(?,?,?,?);");
		ps.setString(1, name);
		ps.setString(2, phone);
		ps.setString(3, email);
		ps.setString(4, hash);
		ps.execute();
	response.sendRedirect("success.html");
	}

	
} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (NoSuchAlgorithmException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}


}
    
	private static String generateHash(String data, String algorithm) throws NoSuchAlgorithmException {
	     MessageDigest digest = MessageDigest.getInstance(algorithm);
	     digest.reset();
	     byte[] hash = digest.digest(data.getBytes());
	     return bytesToStringHex(hash);
	     
			
		}
	
	private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
	private static String bytesToStringHex(byte[] bytes) {
char[] hexChars = new char[bytes.length * 2];
for(int j=0;j<bytes.length;j++)
{
	int v = bytes[j] & 0xFF;
	hexChars[j*2] = hexArray[v >>> 4];
	hexChars[j*2+1]=hexArray[v & 0x0F];
}
return new String(hexChars);
	}
}