package ResetPasswordServlet;
 
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
 

@WebServlet("/reset_password")
public class ResetPasswordServlet extends HttpServlet {
	
    private static final Random RANDOM = new SecureRandom();
    private static final String ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final long serialVersionUID = 1L;
 
    private String host;
    private String port;
    private String email;
    private String name;
    private String pass;
 
    public void init() {
        // reads SMTP server setting from web.xml file
        ServletContext context = getServletContext();
        host = context.getInitParameter("host");
        port = context.getInitParameter("port");
        email = context.getInitParameter("email");
        name = context.getInitParameter("name");
        pass = context.getInitParameter("pass");
    }
 
    public ResetPasswordServlet() {
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
 
        String page = "resetpassword.jsp";
        request.getRequestDispatcher(page).forward(request, response);
 
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	response.setContentType("text/html");  
    	PrintWriter out=response.getWriter();
    	try {
            String recipient = request.getParameter("email");
			Class.forName("com.mysql.jdbc.Driver");
	    	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/socialmedia","root","");
	        Statement st = con.createStatement();
	        ResultSet rs = st.executeQuery("select * from register where email='"+recipient+"'");
	        if(rs.next())
	        {

        String subject = "Password reset link";
 
        // Define desired password length
        int passwordLength = 10;
        
        // Generate Secure Password
        String password = generatePassword(passwordLength);
        
    	String algorithm = "SHA-256";
    	String hash = generateHash(password,algorithm);
        
       // st.executeUpdate("update login set hash='"+hash+"' where email='"+recipient+"'");
 
        String content = "Hello User, Please Click the link -> 'http://localhost:8080/finalhash/newpassword.html' to reset your password.";
        Cookie ck1=new Cookie("email",recipient);
        ck1.setMaxAge(100);
        response.addCookie(ck1);
        String message = "";
 
        try {
            EmailUtility.sendEmail(host, port, email, name, pass,
                    recipient, subject, content);
            message = " Password reset link has been sent to our e-mail . Please check your e-mail.";
        } catch (Exception ex) {
            ex.printStackTrace();
            message = "There were an error: " + ex.getMessage();
        } finally {
            request.setAttribute("message", message);
            request.getRequestDispatcher("message.jsp").forward(request, response);
        }
	        }
	        else
	        {
	            out.println("<!DOCTYPE html>"); 
	            out.println("<html>");
	            out.println("<head>");
	            out.println("<title>ResetPasswordServlet </title>"); 
	            out.println("</head>");
	           	out.print("<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" integrity=\"sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u\" crossorigin=\"anonymous\">\n" + 
	           			"");
	            out.println("<body>");
	            out.println("<center><h1>Please enter the registered email id</h1></center>"); 
	            out.println("<center><button  class=\"btn btn-danger\"><a href=\"login.html\" style=\"color:white;\">Login</a></button></center>");
	            out.println("</body>");
	            out.println("</html>");
	        }
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
    }
    public static String generatePassword(int length) {
        StringBuilder returnValue = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            returnValue.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        return new String(returnValue);
    }
    
	private static String generateHash(String data, String algorithm) throws NoSuchAlgorithmException {
	     MessageDigest digest = MessageDigest.getInstance(algorithm);
	     digest.reset();
	     byte[] hash = digest.digest(data.getBytes());
	     return bytesToStringHex(hash);
	     
			
		}
	
	private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
	private static String bytesToStringHex(byte[] bytes) {
char[] hexChars = new char[bytes.length * 2];
for(int j=0;j<bytes.length;j++)
{
	int v = bytes[j] & 0xFF;
	hexChars[j*2] = hexArray[v >>> 4];
	hexChars[j*2+1]=hexArray[v & 0x0F];
}
return new String(hexChars);
	}
 
}